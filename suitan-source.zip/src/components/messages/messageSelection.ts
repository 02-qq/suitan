import { create } from 'zustand'

/** 消息多选状态：开启后每条消息前出现勾选按钮，底部出现批量操作栏 */
type MessageSelectionState = {
  active: boolean
  ids: Record<string, true>
  start: () => void
  stop: () => void
  toggle: (id: string) => void
  selectAll: (ids: string[]) => void
}

export const useMessageSelection = create<MessageSelectionState>((set) => ({
  active: false,
  ids: {},
  start: () => set({ active: true, ids: {} }),
  stop: () => set({ active: false, ids: {} }),
  toggle: (id) =>
    set((state) => {
      const ids: Record<string, true> = { ...state.ids }
      if (ids[id]) {
        delete ids[id]
      } else {
        ids[id] = true
      }
      return { ids }
    }),
  selectAll: (list) =>
    set(() => {
      const ids: Record<string, true> = {}
      for (const id of list) {
        ids[id] = true
      }
      return { ids }
    }),
}))
