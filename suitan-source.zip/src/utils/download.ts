/**
 * 把文件交给系统保存。
 * 安卓 App 里 WebView 默认不处理 <a download>，所以优先走注入的原生桥（写到「下载/DeepSeek」）；
 * 在普通浏览器里退回 Blob + 下载链接。
 */

type SaveBridge = {
  saveText?: (fileName: string, content: string) => string
  saveBase64?: (fileName: string, mimeType: string, base64: string) => string
}

export type SaveResult = {
  /** 是否走了原生保存 */
  native: boolean
  ok: boolean
  /** 原生保存的位置描述 */
  location?: string
}

const getBridge = (): SaveBridge | undefined =>
  (window as unknown as { AndroidSave?: SaveBridge }).AndroidSave

const blobToBase64 = (blob: Blob): Promise<string> =>
  new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => {
      const result = String(reader.result ?? '')
      const comma = result.indexOf(',')
      resolve(comma >= 0 ? result.slice(comma + 1) : '')
    }
    reader.onerror = () => reject(reader.error ?? new Error('读取文件失败'))
    reader.readAsDataURL(blob)
  })

export const saveFile = async (name: string, blob: Blob): Promise<SaveResult> => {
  const bridge = getBridge()
  if (bridge?.saveBase64) {
    const base64 = await blobToBase64(blob)
    const result = bridge.saveBase64(name, blob.type || 'application/octet-stream', base64)
    const ok = typeof result === 'string' && result.startsWith('ok')
    return { native: true, ok, location: ok ? `下载/DeepSeek/${name}` : result }
  }
  try {
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = name
    link.click()
    setTimeout(() => URL.revokeObjectURL(url), 10_000)
    return { native: false, ok: true }
  } catch {
    return { native: false, ok: false }
  }
}
