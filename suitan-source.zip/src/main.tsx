import { createRoot } from 'react-dom/client'
import { setupTheme } from './app/theme.js'
import './app/global.css'
import './app/theme.css'
import './companion/companion.css'
import { App } from './companion/App.js'

setupTheme()

const container = document.getElementById('root')
if (container) {
  createRoot(container).render(<App />)
}
