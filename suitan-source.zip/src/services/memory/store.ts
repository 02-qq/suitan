import { create } from 'zustand'
import { createId } from '../../utils/id.js'
import * as db from '../chat/db.js'
import {
  MEMORY_LIMIT,
  type MemoryItem,
  type MemoryKind,
  type MemoryStatus,
  type MemoryTier,
  type Persona,
  type RelationState,
  type UserProfile,
} from './types.js'

const now = () => Date.now()

export const emptyProfile = (): UserProfile => ({
  id: 'default',
  displayName: '我',
  facts: [],
  taboos: [],
  updatedAt: now(),
})

export const defaultRelation = (personaId: string): RelationState => ({
  id: personaId,
  personaId,
  stage: '初见',
  affinity: 0,
  mood: '平静',
  lastEvent: '刚刚认识',
  updatedAt: now(),
})

const halfLifeFor = (persona: Persona | undefined, tier: MemoryTier): number => {
  if (tier === 'important') {
    return persona?.halfLifeImportant ?? 180
  }
  if (tier === 'normal') {
    return persona?.halfLifeNormal ?? 14
  }
  return 36500
}

type MemoryState = {
  ready: boolean
  personas: Persona[]
  memories: MemoryItem[]
  relations: Record<string, RelationState>
  profile: UserProfile
  load: () => Promise<void>
  savePersona: (persona: Persona) => void
  createPersona: (input: { name: string; personaCard: string; themeColor?: string }) => Persona
  removePersona: (id: string) => void
  addMemory: (input: {
    personaId: string
    tier: MemoryTier
    text: string
    kind?: MemoryKind
    tags?: string[]
    status?: MemoryStatus
    pinned?: boolean
    sourceMessageIds?: string[]
    strength?: number
  }) => MemoryItem | null
  updateMemory: (id: string, patch: Partial<MemoryItem>) => void
  removeMemory: (id: string) => void
  setRelation: (personaId: string, patch: Partial<RelationState>) => void
  setProfile: (patch: Partial<UserProfile>) => void
  relationOf: (personaId: string) => RelationState
  /** 记录一次命中，用于排序加权；不改 updatedAt，避免重置衰减 */
  markHit: (id: string) => void
  /** 本地整理：过期的日常记忆归档 + 同层同文去重合并 */
  organize: (personaId: string) => { archived: number; merged: number }
}

const palette = ['#c96f4a', '#7a8b5a', '#5a7d8b', '#8b6a94', '#b0743f', '#4e7a63']

const persist = <T,>(action: Promise<T> | void) => {
  if (action instanceof Promise) {
    void action.catch(db.reportStorageError('memory'))
  }
}

export const useMemoryStore = create<MemoryState>((set, get) => ({
  ready: false,
  personas: [],
  memories: [],
  relations: {},
  profile: emptyProfile(),

  load: async () => {
    try {
      const [personas, memories, relations, profile] = await Promise.all([
        db.loadPersonas(),
        db.loadMemories(),
        db.loadRelationStates(),
        db.loadUserProfile(),
      ])
      set({
        ready: true,
        personas,
        memories,
        relations: Object.fromEntries(relations.map((item) => [item.personaId, item])),
        profile: profile ?? emptyProfile(),
      })
    } catch (error) {
      db.reportStorageError('load memory')(error)
      set({ ready: true })
    }
  },

  savePersona: (persona) => {
    const next = { ...persona, updatedAt: now() }
    set((state) => ({
      personas: state.personas.some((item) => item.id === next.id)
        ? state.personas.map((item) => (item.id === next.id ? next : item))
        : [...state.personas, next],
    }))
    persist(db.savePersona(next))
  },

  createPersona: ({ name, personaCard, themeColor }) => {
    const persona: Persona = {
      id: createId(),
      name: name.trim() || '未命名',
      personaCard: personaCard.trim(),
      themeColor: themeColor ?? palette[get().personas.length % palette.length],
      halfLifeImportant: 180,
      halfLifeNormal: 14,
      createdAt: now(),
      updatedAt: now(),
    }
    set((state) => ({ personas: [...state.personas, persona] }))
    persist(db.savePersona(persona))
    return persona
  },

  removePersona: (id) => {
    set((state) => ({
      personas: state.personas.filter((item) => item.id !== id),
      memories: state.memories.filter((item) => item.personaId !== id),
    }))
    persist(db.deletePersonaRecord(id))
  },

  addMemory: (input) => {
    const text = input.text.trim().slice(0, 160)
    if (!text) {
      return null
    }
    const persona = get().personas.find((item) => item.id === input.personaId)
    const tier = input.tier
    const sameTier = get().memories.filter(
      (item) => item.personaId === input.personaId && item.tier === tier && item.status !== 'archived'
    )
    const duplicates = sameTier.find((item) => item.text === text)
    if (duplicates) {
      return duplicates
    }
    const item: MemoryItem = {
      id: createId(),
      personaId: input.personaId,
      tier,
      kind: input.kind ?? (tier === 'normal' ? 'daily' : 'milestone'),
      text,
      sourceMessageIds: input.sourceMessageIds ?? [],
      tags: input.tags ?? [],
      strength: input.strength ?? 0.5,
      status: input.status ?? 'active',
      pinned: input.pinned ?? false,
      halfLifeDays: halfLifeFor(persona, tier),
      createdAt: now(),
      updatedAt: now(),
      hitCount: 0,
    }
    let memories = [...get().memories, item]
    const limit = MEMORY_LIMIT[tier]
    const overflow = memories.filter(
      (one) => one.personaId === item.personaId && one.tier === tier && one.status !== 'archived'
    )
    if (overflow.length > limit) {
      const drop = overflow
        .filter((one) => !one.pinned)
        .sort((a, b) => a.updatedAt - b.updatedAt)
        .slice(0, overflow.length - limit)
      const dropIds = new Set(drop.map((one) => one.id))
      memories = memories.filter((one) => !dropIds.has(one.id))
      for (const gone of drop) {
        persist(db.deleteMemoryRecord(gone.id))
      }
    }
    set({ memories })
    persist(db.saveMemory(item))
    return item
  },

  updateMemory: (id, patch) => {
    const current = get().memories.find((item) => item.id === id)
    if (!current) {
      return
    }
    const next: MemoryItem = { ...current, ...patch, updatedAt: now() }
    set((state) => ({
      memories: state.memories.map((item) => (item.id === id ? next : item)),
    }))
    persist(db.saveMemory(next))
  },

  removeMemory: (id) => {
    set((state) => ({ memories: state.memories.filter((item) => item.id !== id) }))
    persist(db.deleteMemoryRecord(id))
  },

  setRelation: (personaId, patch) => {
    const current = get().relations[personaId] ?? defaultRelation(personaId)
    const clean: Record<string, unknown> = {}
    for (const [key, value] of Object.entries(patch)) {
      if (value !== undefined && key !== 'id' && key !== 'personaId' && key !== 'updatedAt') {
        clean[key] = value
      }
    }
    const next: RelationState = {
      ...current,
      ...(clean as Partial<RelationState>),
      id: personaId,
      personaId,
      updatedAt: now(),
    }
    set((state) => ({ relations: { ...state.relations, [personaId]: next } }))
    persist(db.saveRelationState(next))
  },

  setProfile: (patch) => {
    const next: UserProfile = { ...get().profile, ...patch, id: 'default', updatedAt: now() }
    set({ profile: next })
    persist(db.saveUserProfile(next))
  },

  relationOf: (personaId) => get().relations[personaId] ?? defaultRelation(personaId),

  markHit: (id) => {
    const current = get().memories.find((item) => item.id === id)
    if (!current) {
      return
    }
    const next: MemoryItem = {
      ...current,
      hitCount: current.hitCount + 1,
      lastHitAt: now(),
    }
    set((state) => ({
      memories: state.memories.map((item) => (item.id === id ? next : item)),
    }))
    persist(db.saveMemory(next))
  },

  organize: (personaId) => {
    const current = now()
    const mine = get().memories.filter((item) => item.personaId === personaId)
    const others = get().memories.filter((item) => item.personaId !== personaId)
    const updates = new Map<string, MemoryItem>()
    let archived = 0
    for (const item of mine) {
      if (item.tier === 'normal' && !item.pinned && item.status === 'active') {
        const days = (current - item.updatedAt) / 86_400_000
        if (days > item.halfLifeDays * 2) {
          updates.set(item.id, { ...item, status: 'archived' })
          archived += 1
        }
      }
    }
    const working = mine.map((item) => updates.get(item.id) ?? item)
    const groups = new Map<string, MemoryItem[]>()
    for (const item of working) {
      const key = `${item.tier}|${item.status}|${item.text.replace(/\s/g, '')}`
      const list = groups.get(key)
      if (list) {
        list.push(item)
      } else {
        groups.set(key, [item])
      }
    }
    const result: MemoryItem[] = []
    const removed: string[] = []
    let merged = 0
    for (const list of groups.values()) {
      if (list.length === 1) {
        result.push(list[0])
        continue
      }
      const sorted = [...list].sort((a, b) => b.hitCount - a.hitCount || b.updatedAt - a.updatedAt)
      const winner = sorted[0]
      result.push({
        ...winner,
        hitCount: list.reduce((sum, item) => sum + item.hitCount, 0),
        sourceMessageIds: [...new Set(list.flatMap((item) => item.sourceMessageIds))],
      })
      for (const loser of sorted.slice(1)) {
        removed.push(loser.id)
        merged += 1
      }
    }
    set({ memories: [...others, ...result] })
    for (const item of result) {
      persist(db.saveMemory(item))
    }
    for (const id of removed) {
      persist(db.deleteMemoryRecord(id))
    }
    return { archived, merged }
  },
}))
