import type { AssistantMessage, Message } from '../chat/types.js'
import { estimateTextTokens } from '../chat/context.js'
import { useMemoryStore } from './store.js'
import type { MemoryItem, MemoryTier } from './types.js'

/**
 * 记忆 → 提示词的桥接层。
 * buildInjection：每轮按预算组装「角色设定 + 用户档案 + 核心/重要/一般记忆 + 相关原文」。
 * captureReply：解析回答末尾的 [[STATE]] / [[MEMO]] 标记，写回记忆库并从正文里剥掉。
 */

export type Injection = {
  /** 稳定前缀，拼在 system 里（可吃缓存） */
  system: string
  /** 动态块，DeepSeek 原生协议用 latest_reminder 注入 */
  reminders: string[]
  /** 全部内容合成一段，OpenAI 兼容协议直接拼进 system */
  flat: string
}

const SEPARATORS = /[\s，。！？、,.!?;；:："'（）()【】\[\]~—…·]/g

const bigrams = (text: string): Set<string> => {
  const clean = text.replace(SEPARATORS, '')
  const grams = new Set<string>()
  for (let index = 0; index + 1 < clean.length; index += 1) {
    grams.add(clean.slice(index, index + 2))
  }
  return grams
}

const overlap = (left: Set<string>, right: Set<string>): number => {
  if (left.size === 0 || right.size === 0) {
    return 0
  }
  let hit = 0
  for (const gram of left) {
    if (right.has(gram)) {
      hit += 1
    }
  }
  return hit / Math.max(1, Math.min(left.size, right.size))
}

const scoreOf = (item: MemoryItem, grams: Set<string>, now: number): number => {
  const tierWeight = item.tier === 'important' ? 1 : 0.6
  const days = Math.max(0, (now - item.updatedAt) / 86_400_000)
  const decay = Math.pow(0.5, days / Math.max(1, item.halfLifeDays))
  const keyword = overlap(bigrams(`${item.text}${item.tags.join('')}`), grams)
  const useBoost = 1 + (0.3 * Math.min(item.hitCount, 5)) / 5
  return tierWeight * decay * keyword * useBoost * (item.pinned ? 3 : 1)
}

const trim = (lines: string[], budget: number): string[] => {
  const kept: string[] = []
  let used = 0
  for (const line of lines) {
    const cost = estimateTextTokens(line) + 4
    if (used + cost > budget) {
      break
    }
    kept.push(line)
    used += cost
  }
  return kept
}

const textOf = (message: Message): string =>
  message.role === 'user'
    ? message.content
    : message.blocks.map((block) => (block.type === 'text' ? block.text : '')).join('')

export const buildInjection = (
  personaId: string | undefined,
  question: string,
  messages: Message[]
): Injection | null => {
  if (!personaId) {
    return null
  }
  const state = useMemoryStore.getState()
  const persona = state.personas.find((item) => item.id === personaId)
  if (!persona) {
    return null
  }
  const now = Date.now()
  const grams = bigrams(question)
  const active = state.memories.filter(
    (item) => item.personaId === personaId && item.status === 'active'
  )
  const scored = active.map((item) => ({ item, score: scoreOf(item, grams, now) }))
  const pick = (tier: MemoryTier, limit: number) =>
    scored
      .filter((entry) => entry.item.tier === tier && entry.score > 0)
      .sort((left, right) => right.score - left.score)
      .slice(0, limit)
      .map((entry) => entry.item)

  const core = scored
    .filter((entry) => entry.item.tier === 'core')
    .sort((left, right) => right.score - left.score)
    .map((entry) => entry.item)
  const important = pick('important', 6)
  const normal = pick('normal', 6)

  const systemParts: string[] = []
  if (persona.personaCard.trim()) {
    systemParts.push(`【角色设定】\n${persona.personaCard.trim()}`)
  }
  const profileLines: string[] = []
  const profile = state.profile
  if (profile.displayName && profile.displayName !== '我') {
    profileLines.push(`- 称呼用户为「${profile.displayName}」`)
  }
  for (const fact of trim(profile.facts.map((item) => item.text), 300)) {
    profileLines.push(`- ${fact}`)
  }
  if (profile.taboos.length > 0) {
    profileLines.push(`- 雷区：${profile.taboos.join('、')}`)
  }
  if (profileLines.length > 0) {
    systemParts.push(`【关于用户】\n${profileLines.join('\n')}`)
  }
  const coreLines = trim(core.map((item) => `- ${item.text}`), 300)
  if (coreLines.length > 0) {
    systemParts.push(`【核心记忆】\n${coreLines.join('\n')}`)
  }
  const system = systemParts.join('\n\n')

  const relation = state.relationOf(personaId)
  const reminders: string[] = [
    `【当前关系】${relation.stage}｜亲密度 ${relation.affinity}/100｜情绪：${relation.mood}｜最近：${relation.lastEvent}`,
  ]
  const importantLines = trim(important.map((item) => `- ${item.text}`), 600)
  if (importantLines.length > 0) {
    reminders.push(`【重要记忆】\n${importantLines.join('\n')}`)
  }
  const normalLines = trim(normal.map((item) => `- ${item.text}`), 300)
  if (normalLines.length > 0) {
    reminders.push(`【一般记忆】\n${normalLines.join('\n')}`)
  }

  // 原文回溯：命中记忆指向的最近 2 条原始消息
  const wanted = new Set<string>()
  for (const item of [...important, ...normal].slice(0, 4)) {
    const last = item.sourceMessageIds.at(-1)
    if (last) {
      wanted.add(last)
    }
  }
  const originalLines: string[] = []
  for (const message of messages) {
    if (originalLines.length >= 2 || !wanted.has(message.id)) {
      continue
    }
    const text = textOf(message).trim()
    if (!text) {
      continue
    }
    originalLines.push(
      `${message.role === 'user' ? '用户' : persona.name}：${text.slice(0, 500)}`
    )
  }
  if (originalLines.length > 0) {
    reminders.push(`【相关原文】\n${trim(originalLines, 800).join('\n')}`)
  }

  // 记录命中，供下轮排序加权（不改变 updatedAt，避免重置衰减）
  for (const item of [...important, ...normal]) {
    state.markHit(item.id)
  }

  return { system, reminders, flat: [system, ...reminders].filter(Boolean).join('\n\n') }
}

const MARKER = /^\[\[(STATE|MEMO:(core|important|normal))\]\]\s*(.+)$/

const clean = (value: string): string => value.replace(/｜tags:.*$/, '').trim()

const tagsOf = (value: string): string[] => {
  const match = value.match(/｜tags:\s*(.+)$/)
  if (!match) {
    return []
  }
  return match[1]
    .split(/[,，、\s]+/)
    .map((tag) => tag.trim())
    .filter(Boolean)
    .slice(0, 5)
}

export const captureReply = (
  personaId: string | undefined,
  sourceMessageId: string | null,
  reply: AssistantMessage
): AssistantMessage => {
  if (!personaId) {
    return reply
  }
  const store = useMemoryStore.getState()
  let changed = false
  const captured: { state: string[] | null } = { state: null }
  const pending: { tier: MemoryTier; text: string; tags: string[] }[] = []

  const blocks = reply.blocks.map((block) => {
    if (block.type !== 'text') {
      return block
    }
    const kept: string[] = []
    for (const line of block.text.split('\n')) {
      const match = line.trim().match(MARKER)
      if (!match) {
        kept.push(line)
        continue
      }
      changed = true
      if (match[1] === 'STATE') {
        captured.state = match[3].split('|').map((part) => part.trim())
      } else {
        pending.push({
          tier: match[2] as MemoryTier,
          text: clean(match[3]).slice(0, 160),
          tags: tagsOf(match[3]),
        })
      }
    }
    return { ...block, text: kept.join('\n').replace(/\n{3,}/g, '\n\n').trim() }
  })

  if (captured.state) {
    const [stage, affinity, mood, lastEvent] = captured.state
    const parsed = Number(affinity)
    const patch: { stage?: string; affinity?: number; mood?: string; lastEvent?: string } = {}
    if (stage) {
      patch.stage = stage
    }
    if (Number.isFinite(parsed)) {
      patch.affinity = Math.max(0, Math.min(100, parsed))
    }
    if (mood) {
      patch.mood = mood
    }
    if (lastEvent) {
      patch.lastEvent = lastEvent
    }
    store.setRelation(personaId, patch)
  }

  for (const memory of pending.slice(0, 3)) {
    if (!memory.text) {
      continue
    }
    store.addMemory({
      personaId,
      tier: memory.tier,
      text: memory.text,
      tags: memory.tags,
      status: memory.tier === 'important' ? 'proposed' : 'active',
      sourceMessageIds: sourceMessageId ? [sourceMessageId] : [],
    })
  }

  return changed ? { ...reply, blocks } : reply
}
