/** 记忆库数据模型：角色、用户档案、关系状态、记忆条目 */

export type MemoryTier = 'core' | 'important' | 'normal'

export type MemoryKind = 'persona' | 'profile' | 'milestone' | 'daily' | 'impression' | 'plot'

export type MemoryStatus = 'proposed' | 'active' | 'rejected' | 'archived'

export type Persona = {
  id: string
  name: string
  /** 压缩后的头像 data URL */
  avatar?: string
  /** 人设正文（用户手写） */
  personaCard: string
  themeColor: string
  halfLifeImportant: number
  halfLifeNormal: number
  createdAt: number
  updatedAt: number
}

export type ProfileFact = {
  text: string
  updatedAt: number
}

/** 用户档案跨角色共享，角色只能读 */
export type UserProfile = {
  id: string
  displayName: string
  facts: ProfileFact[]
  taboos: string[]
  updatedAt: number
}

export type RelationState = {
  /** 与 personaId 相同，便于直接 get */
  id: string
  personaId: string
  stage: string
  affinity: number
  mood: string
  lastEvent: string
  updatedAt: number
}

export type MemoryItem = {
  id: string
  personaId: string
  tier: MemoryTier
  kind: MemoryKind
  /** 记忆正文，≤160 字 */
  text: string
  /** 点位：产生这条记忆的原始消息 id */
  sourceMessageIds: string[]
  tags: string[]
  /** 情绪强度 0~1 */
  strength: number
  status: MemoryStatus
  /** 用户锁定：不降级、不淘汰 */
  pinned: boolean
  halfLifeDays: number
  createdAt: number
  updatedAt: number
  lastHitAt?: number
  hitCount: number
}

export const TIER_LABEL: Record<MemoryTier, string> = {
  core: '核心',
  important: '重要',
  normal: '一般',
}

/** 每轮注入预算（token） */
export const MEMORY_BUDGET = {
  important: 600,
  normal: 300,
  original: 800,
  personaCard: 700,
  profile: 350,
  relation: 150,
  system: 120,
} as const

/** 单角色上限 */
export const MEMORY_LIMIT = {
  core: 30,
  important: 200,
  normal: 200,
} as const
