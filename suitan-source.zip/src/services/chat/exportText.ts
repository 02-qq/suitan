import { saveFile, type SaveResult } from '../../utils/download.js'
import { getVisibleMessages } from './branches.js'
import type { Message, Session } from './types.js'

const pad = (value: number) => String(value).padStart(2, '0')

/** 文件名里的时间戳：20261119-2013 */
const stamp = () => {
  const date = new Date()
  return `${date.getFullYear()}${pad(date.getMonth() + 1)}${pad(date.getDate())}-${pad(
    date.getHours()
  )}${pad(date.getMinutes())}`
}

const messageText = (message: Message): string =>
  message.role === 'user'
    ? message.content
    : message.blocks.map((block) => (block.type === 'text' ? block.text : '')).join('')

/**
 * 极简纯文本：每条消息一行前缀 U: 或 A:，不加分隔线、不加时间，
 * 想改前缀只改这两个字母即可。
 */
const lineFor = (message: Message): string => {
  const prefix = message.role === 'user' ? 'U' : 'A'
  const text = messageText(message).trim()
  if (!text) {
    if (message.role === 'user' && message.files.length > 0) {
      return `${prefix}: [附件] ${message.files.map((file) => file.name).join(', ')}`
    }
    return ''
  }
  return `${prefix}: ${text}`
}

export const buildMessagesText = (messages: Message[]): string =>
  messages
    .map(lineFor)
    .filter((line) => line !== '')
    .join('\n')

/** 导出选中（或全部）消息为 TXT；messageIds 为空时导出整个会话 */
export const exportSessionText = async (
  session: Session,
  messageIds?: string[]
): Promise<SaveResult> => {
  const all = getVisibleMessages(session)
  const picked =
    messageIds === undefined
      ? all
      : all.filter((message) => messageIds.includes(message.id))
  const body = buildMessagesText(picked)
  if (!body) {
    return { native: false, ok: false }
  }
  const safeTitle = (session.title || '对话')
    .replace(/[\\/:*?"<>|\r\n\t]+/g, '_')
    .trim()
    .slice(0, 30)
  const name = `${safeTitle}-${stamp()}.txt`
  return saveFile(name, new Blob([`\uFEFF${body}`], { type: 'text/plain;charset=utf-8' }))
}
