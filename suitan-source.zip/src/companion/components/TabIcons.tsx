export const IconRoles = () => (
  <svg
    viewBox="0 0 24 24"
    width="22"
    height="22"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.7"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M4 6.5h16v9.5a2 2 0 0 1-2 2h-7l-4.6 3.2V18H6a2 2 0 0 1-2-2z" />
  </svg>
)

export const IconPlaza = () => (
  <svg
    viewBox="0 0 24 24"
    width="22"
    height="22"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.7"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <circle cx="12" cy="12" r="8.2" />
    <path d="M15.3 8.7l-2 4.6-4.6 2 2-4.6z" />
  </svg>
)

export const IconMine = () => (
  <svg
    viewBox="0 0 24 24"
    width="22"
    height="22"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.7"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <circle cx="12" cy="8.2" r="3.6" />
    <path d="M4.9 20c.9-3.7 3.8-5.7 7.1-5.7s6.2 2 7.1 5.7" />
  </svg>
)
