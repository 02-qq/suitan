import type { ReactNode } from 'react'

/** 从底部弹出的面板 */
export const Sheet = ({
  open,
  title,
  onClose,
  children,
}: {
  open: boolean
  title: string
  onClose: () => void
  children: ReactNode
}) => {
  if (!open) {
    return null
  }
  return (
    <div className="su-mask" onClick={onClose}>
      <div className="su-sheet" onClick={(event) => event.stopPropagation()}>
        <div className="su-sheet-head">
          <span>{title}</span>
          <button type="button" className="su-sheet-close" onClick={onClose}>
            关闭
          </button>
        </div>
        {children}
      </div>
    </div>
  )
}
