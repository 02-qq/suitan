import type { ReactNode } from 'react'
import { useCompanion, type TabKey } from '../store.js'
import { IconMine, IconPlaza, IconRoles } from './TabIcons.js'

const TABS: { key: TabKey; label: string; icon: ReactNode }[] = [
  { key: 'roles', label: '角色', icon: <IconRoles /> },
  { key: 'plaza', label: '广场', icon: <IconPlaza /> },
  { key: 'mine', label: '我的', icon: <IconMine /> },
]

export const TabBar = () => {
  const tab = useCompanion((state) => state.tab)
  const setTab = useCompanion((state) => state.setTab)
  return (
    <nav className="su-tabbar">
      {TABS.map((item) => (
        <button
          key={item.key}
          type="button"
          className={`su-tabbar-item${tab === item.key ? ' on' : ''}`}
          onClick={() => setTab(item.key)}
        >
          <span className="su-tabbar-icon">{item.icon}</span>
          <span className="su-tabbar-label">{item.label}</span>
        </button>
      ))}
    </nav>
  )
}
