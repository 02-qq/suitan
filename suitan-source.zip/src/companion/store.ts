import { create } from 'zustand'

export type CompanionView = 'lobby' | 'chat' | 'memory'

type CompanionState = {
  view: CompanionView
  personaId: string | null
  sessionId: string | null
  /** 从记忆库跳转时闪一下的消息 id */
  highlight: string | null
  settingsOpen: boolean
  openChat: (personaId: string, sessionId: string) => void
  openMemory: (personaId: string) => void
  openLobby: () => void
  jumpTo: (messageId: string) => void
  clearHighlight: () => void
  setSettings: (open: boolean) => void
}

export const useCompanion = create<CompanionState>((set) => ({
  view: 'lobby',
  personaId: null,
  sessionId: null,
  highlight: null,
  settingsOpen: false,
  openChat: (personaId, sessionId) =>
    set({ view: 'chat', personaId, sessionId, highlight: null }),
  openMemory: (personaId) => set({ view: 'memory', personaId }),
  openLobby: () => set({ view: 'lobby', highlight: null }),
  jumpTo: (messageId) => set({ view: 'chat', highlight: messageId }),
  clearHighlight: () => set({ highlight: null }),
  setSettings: (settingsOpen) => set({ settingsOpen }),
}))
