import { create } from 'zustand'

export type TabKey = 'roles' | 'plaza' | 'mine'
export type Screen = 'tabs' | 'chat' | 'memory' | 'sessions'

type CompanionState = {
  screen: Screen
  tab: TabKey
  personaId: string | null
  sessionId: string | null
  /** 从记忆库跳转时闪一下的消息 id */
  highlight: string | null
  settingsOpen: boolean
  setTab: (tab: TabKey) => void
  openChat: (personaId: string, sessionId: string) => void
  openMemory: (personaId: string) => void
  openSessions: (personaId: string) => void
  backToTabs: () => void
  jumpTo: (messageId: string) => void
  clearHighlight: () => void
  setSettings: (open: boolean) => void
}

export const useCompanion = create<CompanionState>((set) => ({
  screen: 'tabs',
  tab: 'roles',
  personaId: null,
  sessionId: null,
  highlight: null,
  settingsOpen: false,
  setTab: (tab) => set({ tab, screen: 'tabs' }),
  openChat: (personaId, sessionId) =>
    set({ screen: 'chat', personaId, sessionId, highlight: null }),
  openMemory: (personaId) => set({ screen: 'memory', personaId }),
  openSessions: (personaId) => set({ screen: 'sessions', personaId }),
  backToTabs: () => set({ screen: 'tabs', highlight: null }),
  jumpTo: (messageId) => set({ screen: 'chat', highlight: messageId }),
  clearHighlight: () => set({ highlight: null }),
  setSettings: (settingsOpen) => set({ settingsOpen }),
}))
