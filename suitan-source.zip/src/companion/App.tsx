import { useEffect, useState } from 'react'
import { Button } from '../components/base/Button.js'
import { Toast } from '../components/base/Toast.js'
import { showToast } from '../components/base/toastState.js'
import { ModelDialog } from '../components/session/ModelDialog.js'
import { initChat } from '../services/chat/store.js'
import { useMemoryStore } from '../services/memory/store.js'
import { setApiKey, useSettings } from '../services/settings.js'
import { Sheet } from './components/Sheet.js'
import { ChatView } from './pages/ChatView.js'
import { Lobby } from './pages/Lobby.js'
import { MemoryView } from './pages/MemoryView.js'
import { useCompanion } from './store.js'

/** 设置：API Key（BYOK）+ 模型 + 关于 */
const SettingsSheet = () => {
  const open = useCompanion((state) => state.settingsOpen)
  const setSettings = useCompanion((state) => state.setSettings)
  const apiKey = useSettings((state) => state.apiKey)
  const [draft, setDraft] = useState(apiKey ?? '')
  const [modelOpen, setModelOpen] = useState(false)

  return (
    <>
      <Sheet open={open} title="设置" onClose={() => setSettings(false)}>
        <label className="su-label">API Key（只保存在这台手机上）</label>
        <input
          className="su-input"
          type="password"
          value={draft}
          placeholder="sk-..."
          onChange={(event) => setDraft(event.target.value)}
        />
        <div className="su-actions">
          <Button
            size="m"
            variant="outlined"
            onClick={() => {
              setApiKey(draft.trim() || null)
              showToast('已保存')
            }}
          >
            保存 Key
          </Button>
          <Button size="m" variant="outlined" onClick={() => setModelOpen(true)}>
            模型
          </Button>
        </div>
        <div className="su-note">
          聊天记录、记忆库和 API Key 都只保存在这台手机上，不会上传到任何服务器；消息会直接发送给你选择的模型服务商。
        </div>
        <div className="su-note">内容由 AI 生成，仅供陪伴娱乐，请勿据此做重要决定。</div>
        <div className="su-note">
          本应用基于开源项目 chat-demo 修改（MIT License，Copyright (c) 2026 DeepSeek）。
        </div>
      </Sheet>
      <ModelDialog open={modelOpen} onClose={() => setModelOpen(false)} />
    </>
  )
}

export const App = () => {
  const view = useCompanion((state) => state.view)
  const personaId = useCompanion((state) => state.personaId)
  const sessionId = useCompanion((state) => state.sessionId)

  useEffect(() => {
    void initChat()
    void useMemoryStore.getState().load()
  }, [])

  return (
    <div className="su-app">
      {view === 'memory' && personaId ? (
        <MemoryView personaId={personaId} />
      ) : view === 'chat' && personaId && sessionId ? (
        <ChatView personaId={personaId} sessionId={sessionId} />
      ) : (
        <Lobby />
      )}
      <SettingsSheet />
      <Toast />
    </div>
  )
}
