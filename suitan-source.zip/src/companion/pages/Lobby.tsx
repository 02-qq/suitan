import { useState } from 'react'
import { Button } from '../../components/base/Button.js'
import { showToast } from '../../components/base/toastState.js'
import { createPersonaSession, selectSession, useChatStore } from '../../services/chat/store.js'
import { useMemoryStore } from '../../services/memory/store.js'
import type { Persona } from '../../services/memory/types.js'
import { useCompanion } from '../store.js'
import { Sheet } from '../components/Sheet.js'

const initialOf = (name: string) => name.trim().slice(0, 1) || '她'

/** 角色大厅：所有角色卡片 + 新建角色 */
export const Lobby = () => {
  const personas = useMemoryStore((state) => state.personas)
  const relations = useMemoryStore((state) => state.relations)
  const createPersona = useMemoryStore((state) => state.createPersona)
  const removePersona = useMemoryStore((state) => state.removePersona)
  const openChat = useCompanion((state) => state.openChat)
  const setSettings = useCompanion((state) => state.setSettings)
  const [creating, setCreating] = useState(false)
  const [name, setName] = useState('')
  const [card, setCard] = useState('')

  const enter = (persona: Persona) => {
    const sessions = useChatStore.getState().sessions
    const existing = sessions.find((item) => item.personaId === persona.id)
    const sessionId = existing?.id ?? createPersonaSession(persona.id, persona.name)
    selectSession(sessionId)
    openChat(persona.id, sessionId)
  }

  const submit = () => {
    if (!name.trim()) {
      showToast('先给她起个名字')
      return
    }
    const persona = createPersona({ name, personaCard: card })
    setCreating(false)
    setName('')
    setCard('')
    showToast('角色已创建')
    enter(persona)
  }

  return (
    <div className="su-screen">
      <div className="su-header">
        <div className="su-header-main">
          <div className="su-title">随谈</div>
          <div className="su-sub">和她们聊聊今天</div>
        </div>
        <button type="button" className="su-iconbtn" aria-label="设置" onClick={() => setSettings(true)}>
          ⚙
        </button>
      </div>
      <div className="su-body">
        {personas.length === 0 ? (
          <div className="su-empty">
            还没有角色。
            <br />
            先创建一个人设，她就会一直记得你们聊过的事。
          </div>
        ) : null}
        {personas.map((persona) => {
          const relation = relations[persona.id]
          return (
            <div
              key={persona.id}
              className="su-card"
              role="button"
              tabIndex={0}
              onClick={() => enter(persona)}
              onKeyDown={(event) => {
                if (event.key === 'Enter') {
                  enter(persona)
                }
              }}
            >
              <div
                className="su-avatar"
                style={{
                  backgroundColor: persona.themeColor,
                  backgroundImage: persona.avatar ? `url("${persona.avatar}")` : undefined,
                }}
              >
                {persona.avatar ? '' : initialOf(persona.name)}
              </div>
              <div className="su-card-main">
                <div className="su-card-name">{persona.name}</div>
                <div className="su-card-meta">
                  {relation ? `${relation.stage} · 亲密度 ${relation.affinity} · ${relation.mood}` : '还没说过话'}
                </div>
              </div>
              <button
                type="button"
                className="su-iconbtn"
                aria-label="删除角色"
                onClick={(event) => {
                  event.stopPropagation()
                  if (window.confirm(`删除「${persona.name}」？她的记忆也会一起删除。`)) {
                    removePersona(persona.id)
                    showToast('已删除')
                  }
                }}
              >
                ⋯
              </button>
            </div>
          )
        })}
        <button type="button" className="su-add" onClick={() => setCreating(true)}>
          ＋ 新建角色
        </button>
      </div>

      <Sheet open={creating} title="新建角色" onClose={() => setCreating(false)}>
        <label className="su-label">她的名字</label>
        <input
          className="su-input"
          value={name}
          placeholder="例如：林晚"
          onChange={(event) => setName(event.target.value)}
        />
        <label className="su-label">人设（越具体，她越像那个人）</label>
        <textarea
          className="su-textarea"
          value={card}
          placeholder={'例如：25 岁，在街角开咖啡店。嘴硬心软，说话简短，偶尔损人但会记住你说过的事。不爱用感叹号。'}
          onChange={(event) => setCard(event.target.value)}
        />
        <div className="su-actions">
          <Button size="m" variant="outlined" onClick={() => setCreating(false)}>
            取消
          </Button>
          <Button size="m" onClick={submit}>
            创建
          </Button>
        </div>
      </Sheet>
    </div>
  )
}
