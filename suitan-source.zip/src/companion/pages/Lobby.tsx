import { useRef, useState } from 'react'
import type { ChangeEvent } from 'react'
import { Button } from '../../components/base/Button.js'
import { showToast } from '../../components/base/toastState.js'
import { createPersonaSession, selectSession, useChatStore } from '../../services/chat/store.js'
import { useMemoryStore } from '../../services/memory/store.js'
import type { Persona } from '../../services/memory/types.js'
import { compressImage } from '../image.js'
import { useCompanion } from '../store.js'
import { Sheet } from '../components/Sheet.js'

const initialOf = (name: string) => name.trim().slice(0, 1) || 'TA'

type EditorState = { mode: 'create' } | { mode: 'edit'; persona: Persona }

/** 新建 / 编辑角色：名字、人设、头像 */
const PersonaEditor = ({
  state,
  onClose,
}: {
  state: EditorState
  onClose: (created?: Persona) => void
}) => {
  const createPersona = useMemoryStore((store) => store.createPersona)
  const savePersona = useMemoryStore((store) => store.savePersona)
  const removePersona = useMemoryStore((store) => store.removePersona)
  const [name, setName] = useState(state.mode === 'edit' ? state.persona.name : '')
  const [card, setCard] = useState(state.mode === 'edit' ? state.persona.personaCard : '')
  const [avatar, setAvatar] = useState<string | undefined>(
    state.mode === 'edit' ? state.persona.avatar : undefined
  )
  const fileRef = useRef<HTMLInputElement>(null)

  const pickAvatar = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    event.target.value = ''
    if (!file) {
      return
    }
    try {
      setAvatar(await compressImage(file, 512))
    } catch {
      showToast('这张图处理失败，换一张试试')
    }
  }

  const submit = () => {
    if (!name.trim()) {
      showToast('先给 TA 起个名字')
      return
    }
    if (state.mode === 'create') {
      const created = createPersona({ name, personaCard: card })
      const withAvatar = avatar ? { ...created, avatar } : created
      if (avatar) {
        savePersona(withAvatar)
      }
      showToast('角色已创建')
      onClose(withAvatar)
      return
    }
    savePersona({
      ...state.persona,
      name: name.trim(),
      personaCard: card,
      avatar,
    })
    showToast('已保存')
    onClose()
  }

  return (
    <Sheet open title={state.mode === 'create' ? '新建角色' : '编辑角色'} onClose={onClose}>
      <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
        <button
          type="button"
          onClick={() => fileRef.current?.click()}
          className="su-avatar"
          style={{
            width: 56,
            height: 56,
            border: 'none',
            backgroundColor: state.mode === 'edit' ? state.persona.themeColor : '#c96f4a',
            backgroundImage: avatar ? `url("${avatar}")` : undefined,
            cursor: 'pointer',
          }}
        >
          {avatar ? '' : initialOf(name)}
        </button>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div className="su-note" style={{ marginTop: 0 }}>
            点头像可以上传（会压缩到 512px）
          </div>
        </div>
        <input
          ref={fileRef}
          type="file"
          accept="image/*"
          style={{ display: 'none' }}
          onChange={pickAvatar}
        />
      </div>

      <label className="su-label">TA 的名字</label>
      <input
        className="su-input"
        value={name}
        placeholder="例如：林晚"
        onChange={(event) => setName(event.target.value)}
      />

      <label className="su-label">人设（越具体，TA 越像那个人）</label>
      <textarea
        className="su-textarea"
        value={card}
        placeholder={'例如：25 岁，在街角开咖啡店。嘴硬心软，说话简短，偶尔损人但会记住你说过的事。不爱用感叹号。'}
        onChange={(event) => setCard(event.target.value)}
      />

      <div className="su-actions">
        <Button size="m" variant="outlined" onClick={onClose}>
          取消
        </Button>
        <Button size="m" onClick={submit}>
          {state.mode === 'create' ? '创建' : '保存'}
        </Button>
      </div>

      {state.mode === 'edit' ? (
        <button
          type="button"
          className="su-danger"
          onClick={() => {
            if (window.confirm(`删除「${state.persona.name}」？TA 的记忆也会一起删除。`)) {
              removePersona(state.persona.id)
              onClose()
              showToast('已删除')
            }
          }}
        >
          删除这个角色
        </button>
      ) : null}
    </Sheet>
  )
}

/** 角色大厅 */
export const Lobby = () => {
  const personas = useMemoryStore((state) => state.personas)
  const relations = useMemoryStore((state) => state.relations)
  const openChat = useCompanion((state) => state.openChat)
  const setSettings = useCompanion((state) => state.setSettings)
  const [editor, setEditor] = useState<EditorState | null>(null)

  const enter = (persona: Persona) => {
    const sessions = useChatStore.getState().sessions
    const existing = sessions.find((item) => item.personaId === persona.id)
    const sessionId = existing?.id ?? createPersonaSession(persona.id, persona.name)
    selectSession(sessionId)
    openChat(persona.id, sessionId)
  }

  return (
    <div className="su-screen">
      <div className="su-hero">
        <div>
          <div className="su-hero-title">随谈</div>
          <div className="su-hero-sub">和 TA 说说今天</div>
        </div>
        <button
          type="button"
          className="su-iconbtn"
          aria-label="设置"
          onClick={() => setSettings(true)}
        >
          ⚙
        </button>
      </div>

      <div className="su-body">
        {personas.length === 0 ? (
          <div className="su-empty">
            还没有角色。
            <br />
            先创建一个人设，TA 会一直记得你们聊过的事。
          </div>
        ) : null}

        {personas.map((persona) => {
          const relation = relations[persona.id]
          return (
            <div
              key={persona.id}
              className="su-card"
              role="button"
              tabIndex={0}
              onClick={() => enter(persona)}
              onKeyDown={(event) => {
                if (event.key === 'Enter') {
                  enter(persona)
                }
              }}
            >
              <div
                className="su-avatar"
                style={{
                  backgroundColor: persona.themeColor,
                  backgroundImage: persona.avatar ? `url("${persona.avatar}")` : undefined,
                }}
              >
                {persona.avatar ? '' : initialOf(persona.name)}
              </div>
              <div className="su-card-main">
                <div className="su-card-name">{persona.name}</div>
                <div className="su-card-meta">
                  {relation
                    ? `${relation.stage} · 亲密度 ${relation.affinity} · ${relation.mood}`
                    : '还没说过话'}
                </div>
              </div>
              <button
                type="button"
                className="su-iconbtn"
                aria-label="编辑角色"
                onClick={(event) => {
                  event.stopPropagation()
                  setEditor({ mode: 'edit', persona })
                }}
              >
                ⋯
              </button>
            </div>
          )
        })}

        <button type="button" className="su-add" onClick={() => setEditor({ mode: 'create' })}>
          ＋ 新建角色
        </button>
      </div>

      {editor ? (
        <PersonaEditor
          state={editor}
          onClose={(created) => {
            setEditor(null)
            if (created) {
              enter(created)
            }
          }}
        />
      ) : null}
    </div>
  )
}
