import { useState } from 'react'
import type { CSSProperties } from 'react'
import { Button } from '../../components/base/Button.js'
import { showToast } from '../../components/base/toastState.js'
import { useMemoryStore } from '../../services/memory/store.js'
import type { MemoryTier } from '../../services/memory/types.js'
import { useCompanion } from '../store.js'

type Tab = 'core' | 'important' | 'normal' | 'proposed'

const TABS: { key: Tab; label: string }[] = [
  { key: 'core', label: '核心' },
  { key: 'important', label: '重要' },
  { key: 'normal', label: '一般' },
  { key: 'proposed', label: '待确认' },
]

const TIER_OPTIONS: { key: MemoryTier; label: string }[] = [
  { key: 'core', label: '核心' },
  { key: 'important', label: '重要' },
  { key: 'normal', label: '一般' },
]

const day = (value: number) => new Date(value).toLocaleDateString('zh-CN')

/** 记忆库：核心 / 重要 / 一般 / 待确认，可增删改、锁定、跳回原文 */
export const MemoryView = ({ personaId }: { personaId: string }) => {
  const persona = useMemoryStore((state) => state.personas.find((item) => item.id === personaId))
  const memories = useMemoryStore((state) => state.memories)
  const addMemory = useMemoryStore((state) => state.addMemory)
  const updateMemory = useMemoryStore((state) => state.updateMemory)
  const removeMemory = useMemoryStore((state) => state.removeMemory)
  const profile = useMemoryStore((state) => state.profile)
  const setProfile = useMemoryStore((state) => state.setProfile)
  const openLobby = useCompanion((state) => state.openLobby)
  const jumpTo = useCompanion((state) => state.jumpTo)
  const [tab, setTab] = useState<Tab>('core')
  const [draft, setDraft] = useState('')
  const [tier, setTier] = useState<MemoryTier>('important')

  const mine = memories.filter((item) => item.personaId === personaId)
  const pending = mine.filter((item) => item.status === 'proposed')
  const items = mine.filter((item) =>
    tab === 'proposed'
      ? item.status === 'proposed'
      : item.tier === tab && item.status === 'active'
  )

  const submit = () => {
    const text = draft.trim()
    if (!text) {
      return
    }
    const created = addMemory({
      personaId,
      tier,
      text,
      status: 'active',
      pinned: tier === 'core',
    })
    if (!created) {
      showToast('这条已经记过了')
      return
    }
    setDraft('')
    showToast('已记住')
  }

  const accent = persona?.themeColor ?? '#c96f4a'

  return (
    <div className="su-screen" style={{ '--su-accent': accent } as CSSProperties}>
      <div className="su-header">
        <button type="button" className="su-iconbtn" aria-label="返回" onClick={openLobby}>
          ‹
        </button>
        <div className="su-header-main">
          <div className="su-title">{persona?.name ?? '她'}的记忆</div>
          <div className="su-sub">
            共 {mine.length} 条{pending.length > 0 ? ` · ${pending.length} 条待确认` : ''}
          </div>
        </div>
      </div>

      <div className="su-body">
        <label className="su-label">她怎么称呼你</label>
        <input
          className="su-input"
          value={profile.displayName}
          placeholder="例如：老周"
          onChange={(event) => setProfile({ displayName: event.target.value })}
        />

        <div className="su-tabs" style={{ marginTop: 12 }}>
          {TABS.map((item) => (
            <button
              key={item.key}
              type="button"
              className={`su-tab${tab === item.key ? ' on' : ''}`}
              onClick={() => setTab(item.key)}
            >
              {item.label}
              {item.key === 'proposed' && pending.length > 0 ? ` ${pending.length}` : ''}
            </button>
          ))}
        </div>

        {tab === 'proposed' ? null : (
          <>
            <textarea
              className="su-textarea"
              value={draft}
              placeholder="写一条要她记住的事，例如：我下周三要答辩，很紧张"
              onChange={(event) => setDraft(event.target.value)}
            />
            <div className="su-tabs" style={{ marginTop: 8 }}>
              {TIER_OPTIONS.map((item) => (
                <button
                  key={item.key}
                  type="button"
                  className={`su-tab${tier === item.key ? ' on' : ''}`}
                  onClick={() => setTier(item.key)}
                >
                  {item.label}
                </button>
              ))}
            </div>
            <Button size="m" block onClick={submit}>
              记住这件事
            </Button>
          </>
        )}

        <div style={{ marginTop: 14 }}>
          {items.length === 0 ? (
            <div className="su-empty">
              {tab === 'proposed' ? '没有待确认的记忆' : '这一层还是空的'}
            </div>
          ) : null}
          {items.map((item) => (
            <div key={item.id} className="su-memo">
              <div className="su-memo-text">{item.text}</div>
              <div className="su-memo-meta">
                <span>{day(item.createdAt)}</span>
                <span>命中 {item.hitCount} 次</span>
                {item.pinned ? <span>已锁定</span> : null}
                {item.sourceMessageIds.length > 0 ? (
                  <button
                    type="button"
                    className="su-link"
                    onClick={() => jumpTo(item.sourceMessageIds[item.sourceMessageIds.length - 1])}
                  >
                    看原文
                  </button>
                ) : null}
                {tab === 'proposed' ? (
                  <>
                    <button
                      type="button"
                      className="su-link"
                      onClick={() => {
                        updateMemory(item.id, { status: 'active' })
                        showToast('已采纳')
                      }}
                    >
                      采纳
                    </button>
                    <button
                      type="button"
                      className="su-link"
                      onClick={() => {
                        updateMemory(item.id, { status: 'rejected' })
                        showToast('已忽略')
                      }}
                    >
                      忽略
                    </button>
                  </>
                ) : (
                  <>
                    <button
                      type="button"
                      className="su-link"
                      onClick={() => updateMemory(item.id, { pinned: !item.pinned })}
                    >
                      {item.pinned ? '解锁' : '锁定'}
                    </button>
                    <button
                      type="button"
                      className="su-link"
                      onClick={() => {
                        removeMemory(item.id)
                        showToast('已删除')
                      }}
                    >
                      删除
                    </button>
                  </>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
