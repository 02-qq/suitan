import { useEffect, useRef, useState } from 'react'
import type { CSSProperties } from 'react'
import { showToast } from '../../components/base/toastState.js'
import { getVisibleMessages } from '../../services/chat/branches.js'
import {
  deleteMessages,
  regenerateReply,
  sendTextMessage,
  stopReply,
  useChatStore,
} from '../../services/chat/store.js'
import type { Message } from '../../services/chat/types.js'
import { useMemoryStore } from '../../services/memory/store.js'
import { Sheet } from '../components/Sheet.js'
import { exportMemoir } from '../export.js'
import { useCompanion } from '../store.js'

/** 记忆标记不出现在聊天里 */
const stripMarkers = (text: string): string =>
  text
    .split('\n')
    .filter((line) => !line.trim().startsWith('[['))
    .join('\n')
    .trim()

const messageText = (message: Message): string =>
  message.role === 'user'
    ? message.content
    : stripMarkers(
        message.blocks.map((block) => (block.type === 'text' ? block.text : '')).join('')
      )

const isAction = (text: string) => /^\*[\s\S]*\*$/.test(text.trim())

/** 聊天剧场 */
export const ChatView = ({ personaId, sessionId }: { personaId: string; sessionId: string }) => {
  const persona = useMemoryStore((state) => state.personas.find((item) => item.id === personaId))
  const relation = useMemoryStore((state) => state.relations[personaId])
  const userName = useMemoryStore((state) =>
    state.profile.displayName && state.profile.displayName !== '我'
      ? state.profile.displayName
      : '我'
  )
  const session = useChatStore((state) =>
    Object.hasOwn(state.sessionCache, sessionId) ? state.sessionCache[sessionId] : undefined
  )
  const streaming = useChatStore((state) => Object.hasOwn(state.streaming, sessionId))
  const backToTabs = useCompanion((state) => state.backToTabs)
  const openMemory = useCompanion((state) => state.openMemory)
  const openSessions = useCompanion((state) => state.openSessions)
  const highlight = useCompanion((state) => state.highlight)
  const clearHighlight = useCompanion((state) => state.clearHighlight)
  const [draft, setDraft] = useState('')
  const [moreOpen, setMoreOpen] = useState(false)
  const bodyRef = useRef<HTMLDivElement>(null)

  const messages = session ? getVisibleMessages(session) : []
  const lastId = messages.at(-1)?.id

  useEffect(() => {
    const body = bodyRef.current
    if (body) {
      body.scrollTop = body.scrollHeight
    }
  }, [lastId, streaming])

  useEffect(() => {
    if (!highlight) {
      return undefined
    }
    const node = bodyRef.current?.querySelector(`[data-mid="${highlight}"]`)
    node?.scrollIntoView({ block: 'center' })
    const timer = window.setTimeout(clearHighlight, 1600)
    return () => window.clearTimeout(timer)
  }, [highlight, clearHighlight])

  const send = () => {
    const text = draft.trim()
    if (!text || streaming) {
      return
    }
    if (sendTextMessage(sessionId, text)) {
      setDraft('')
    }
  }

  const regenerateLast = () => {
    const reply = [...messages].reverse().find((message) => message.role === 'assistant')
    if (!reply || streaming) {
      showToast('还没有可以重说的回答')
      return
    }
    regenerateReply(sessionId, reply.id)
    setMoreOpen(false)
  }

  const removeLast = () => {
    const last = messages.at(-1)
    if (!last || streaming) {
      return
    }
    if (!window.confirm('删除最后一条消息？')) {
      return
    }
    deleteMessages(sessionId, [last.id])
    setMoreOpen(false)
  }

  const exportNow = async () => {
    if (!persona || !session) {
      return
    }
    setMoreOpen(false)
    const result = await exportMemoir(persona, session, userName)
    showToast(result.ok ? '回忆录已导出' : '导出失败')
  }

  const accent = persona?.themeColor ?? '#c96f4a'
  const stage = relation
    ? `${relation.stage} · 亲密度 ${relation.affinity} · ${relation.mood}`
    : '初见 · 亲密度 0 · 平静'

  return (
    <div className="su-screen" style={{ '--su-accent': accent } as CSSProperties}>
      <div className="su-scene" aria-hidden="true" />

      <div className="su-header su-header-float">
        <button type="button" className="su-iconbtn" aria-label="返回" onClick={backToTabs}>
          ‹
        </button>
        <div
          className="su-avatar su-avatar-sm"
          style={{
            backgroundColor: accent,
            backgroundImage: persona?.avatar ? `url("${persona.avatar}")` : undefined,
          }}
        >
          {persona?.avatar ? '' : (persona?.name ?? 'TA').slice(0, 1)}
        </div>
        <div className="su-header-main">
          <div className="su-title">{persona?.name ?? 'TA'}</div>
          <div className="su-sub">{stage}</div>
        </div>
        <button
          type="button"
          className="su-iconbtn"
          aria-label="记忆库"
          onClick={() => openMemory(personaId)}
        >
          ◍
        </button>
        <button
          type="button"
          className="su-iconbtn"
          aria-label="更多"
          onClick={() => setMoreOpen(true)}
        >
          ⋯
        </button>
      </div>

      <div className="su-body" ref={bodyRef}>
        <div className="su-messages">
          {messages.map((message) => {
            const text = messageText(message)
            if (message.role === 'user' && isAction(text)) {
              return (
                <div
                  key={message.id}
                  className={`su-action${highlight === message.id ? ' su-flash' : ''}`}
                  data-mid={message.id}
                >
                  {text.trim().slice(1, -1)}
                </div>
              )
            }
            if (!text) {
              return null
            }
            return (
              <div key={message.id} className={`su-row${message.role === 'user' ? ' me' : ''}`}>
                <div
                  className={`su-bubble ${message.role === 'user' ? 'me' : 'her'}${
                    highlight === message.id ? ' su-flash' : ''
                  }`}
                  data-mid={message.id}
                >
                  {text}
                </div>
              </div>
            )
          })}
          {streaming ? (
            <div className="su-typing">
              <span className="su-dot" />
              <span className="su-dot" />
              <span className="su-dot" />
            </div>
          ) : null}
          {messages.length === 0 ? <div className="su-empty">说句话，让 TA 认识你。</div> : null}
        </div>
      </div>

      <div className="su-composer-wrap">
        <div className="su-composer">
          <button
            type="button"
            className="su-actbtn"
            aria-label="动作"
            onClick={() =>
              setDraft((current) => (isAction(current) ? current.slice(1, -1) : `*${current}*`))
            }
          >
            动作
          </button>
          <textarea
            className="su-composer-text"
            rows={1}
            value={draft}
            placeholder={`和${persona?.name ?? 'TA'}说点什么…`}
            onChange={(event) => setDraft(event.target.value)}
            onKeyDown={(event) => {
              if (event.key === 'Enter' && !event.shiftKey && !event.nativeEvent.isComposing) {
                event.preventDefault()
                send()
              }
            }}
          />
          {streaming ? (
            <button type="button" className="su-send" onClick={() => stopReply(sessionId)}>
              停止
            </button>
          ) : (
            <button type="button" className="su-send" disabled={!draft.trim()} onClick={send}>
              发送
            </button>
          )}
        </div>
      </div>

      <Sheet open={moreOpen} title="更多" onClose={() => setMoreOpen(false)}>
        <button type="button" className="su-menu-item" onClick={regenerateLast}>
          让 TA 重说最后一句
        </button>
        <button type="button" className="su-menu-item" onClick={removeLast}>
          删除最后一条消息
        </button>
        <button
          type="button"
          className="su-menu-item"
          onClick={() => {
            setMoreOpen(false)
            openSessions(personaId)
          }}
        >
          剧情存档
        </button>
        <button type="button" className="su-menu-item" onClick={() => void exportNow()}>
          导出回忆录（TXT）
        </button>
      </Sheet>
    </div>
  )
}
