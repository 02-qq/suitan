import { useEffect, useRef, useState } from 'react'
import type { CSSProperties } from 'react'
import { getVisibleMessages } from '../../services/chat/branches.js'
import { sendTextMessage, stopReply, useChatStore } from '../../services/chat/store.js'
import type { Message } from '../../services/chat/types.js'
import { useMemoryStore } from '../../services/memory/store.js'
import { useCompanion } from '../store.js'

/** 记忆标记不出现在聊天里 */
const stripMarkers = (text: string): string =>
  text
    .split('\n')
    .filter((line) => !line.trim().startsWith('[['))
    .join('\n')
    .trim()

const messageText = (message: Message): string =>
  message.role === 'user'
    ? message.content
    : stripMarkers(
        message.blocks.map((block) => (block.type === 'text' ? block.text : '')).join('')
      )

const isAction = (text: string) => /^\*[\s\S]*\*$/.test(text.trim())

/** 聊天剧场：她 + 关系状态条 + 对话流 + 输入 */
export const ChatView = ({ personaId, sessionId }: { personaId: string; sessionId: string }) => {
  const persona = useMemoryStore((state) => state.personas.find((item) => item.id === personaId))
  const relation = useMemoryStore((state) => state.relations[personaId])
  const session = useChatStore((state) =>
    Object.hasOwn(state.sessionCache, sessionId) ? state.sessionCache[sessionId] : undefined
  )
  const streaming = useChatStore((state) => Object.hasOwn(state.streaming, sessionId))
  const openLobby = useCompanion((state) => state.openLobby)
  const openMemory = useCompanion((state) => state.openMemory)
  const highlight = useCompanion((state) => state.highlight)
  const clearHighlight = useCompanion((state) => state.clearHighlight)
  const [draft, setDraft] = useState('')
  const bodyRef = useRef<HTMLDivElement>(null)

  const messages = session ? getVisibleMessages(session) : []
  const lastId = messages.at(-1)?.id

  useEffect(() => {
    const body = bodyRef.current
    if (body) {
      body.scrollTop = body.scrollHeight
    }
  }, [lastId, streaming])

  useEffect(() => {
    if (!highlight) {
      return undefined
    }
    const node = bodyRef.current?.querySelector(`[data-mid="${highlight}"]`)
    node?.scrollIntoView({ block: 'center' })
    const timer = window.setTimeout(clearHighlight, 1600)
    return () => window.clearTimeout(timer)
  }, [highlight, clearHighlight])

  const send = () => {
    const text = draft.trim()
    if (!text || streaming) {
      return
    }
    if (sendTextMessage(sessionId, text)) {
      setDraft('')
    }
  }

  const accent = persona?.themeColor ?? '#c96f4a'

  return (
    <div className="su-screen" style={{ '--su-accent': accent } as CSSProperties}>
      <div className="su-header">
        <button type="button" className="su-iconbtn" aria-label="返回" onClick={openLobby}>
          ‹
        </button>
        <div
          className="su-avatar"
          style={{
            backgroundColor: accent,
            backgroundImage: persona?.avatar ? `url("${persona.avatar}")` : undefined,
            width: 38,
            height: 38,
            fontSize: 16,
          }}
        >
          {persona?.avatar ? '' : (persona?.name ?? '她').slice(0, 1)}
        </div>
        <div className="su-header-main">
          <div className="su-title">{persona?.name ?? '她'}</div>
          <div className="su-sub">
            {relation
              ? `${relation.stage} · 亲密度 ${relation.affinity} · ${relation.mood}`
              : '初见 · 亲密度 0 · 平静'}
          </div>
        </div>
        <button
          type="button"
          className="su-iconbtn"
          aria-label="记忆库"
          onClick={() => openMemory(personaId)}
        >
          ◍
        </button>
      </div>

      <div className="su-body" ref={bodyRef}>
        <div className="su-messages">
          {messages.map((message) => {
            const text = messageText(message)
            if (message.role === 'user' && isAction(text)) {
              return (
                <div
                  key={message.id}
                  className={`su-action${highlight === message.id ? ' su-flash' : ''}`}
                  data-mid={message.id}
                >
                  {text.trim().slice(1, -1)}
                </div>
              )
            }
            if (!text) {
              return null
            }
            return (
              <div key={message.id} className={`su-row${message.role === 'user' ? ' me' : ''}`}>
                <div
                  className={`su-bubble ${message.role === 'user' ? 'me' : 'her'}${
                    highlight === message.id ? ' su-flash' : ''
                  }`}
                  data-mid={message.id}
                >
                  {text}
                </div>
              </div>
            )
          })}
          {streaming ? <div className="su-typing">正在输入…</div> : null}
          {messages.length === 0 ? (
            <div className="su-empty">说句话，让她认识你。</div>
          ) : null}
        </div>
      </div>

      <div className="su-composer">
        <button
          type="button"
          className="su-actbtn"
          onClick={() =>
            setDraft((current) => (isAction(current) ? current.slice(1, -1) : `*${current}*`))
          }
        >
          动作
        </button>
        <textarea
          className="su-composer-text"
          rows={1}
          value={draft}
          placeholder="说点什么…"
          onChange={(event) => setDraft(event.target.value)}
          onKeyDown={(event) => {
            if (event.key === 'Enter' && !event.shiftKey && !event.nativeEvent.isComposing) {
              event.preventDefault()
              send()
            }
          }}
        />
        {streaming ? (
          <button type="button" className="su-send" onClick={() => stopReply(sessionId)}>
            停止
          </button>
        ) : (
          <button type="button" className="su-send" disabled={!draft.trim()} onClick={send}>
            发送
          </button>
        )}
      </div>
    </div>
  )
}
