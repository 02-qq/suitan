import { showToast } from '../../components/base/toastState.js'
import {
  createPersonaSession,
  removeSession,
  selectSession,
  useChatStore,
} from '../../services/chat/store.js'
import { useMemoryStore } from '../../services/memory/store.js'
import { useCompanion } from '../store.js'

const formatDay = (value: number) => {
  const date = new Date(value)
  const pad = (n: number) => String(n).padStart(2, '0')
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(
    date.getHours()
  )}:${pad(date.getMinutes())}`
}

/** 剧情存档：一个角色的多条时间线 */
export const SessionsView = ({ personaId }: { personaId: string }) => {
  const persona = useMemoryStore((state) => state.personas.find((item) => item.id === personaId))
  const sessions = useChatStore((state) => state.sessions)
  const openChat = useCompanion((state) => state.openChat)
  const backToTabs = useCompanion((state) => state.backToTabs)
  const mine = sessions.filter((session) => session.personaId === personaId)

  const create = () => {
    const sessionId = createPersonaSession(personaId, persona?.name ?? '新剧情')
    selectSession(sessionId)
    openChat(personaId, sessionId)
  }

  return (
    <div className="su-screen">
      <div className="su-header">
        <button type="button" className="su-iconbtn" aria-label="返回" onClick={backToTabs}>
          ‹
        </button>
        <div className="su-header-main">
          <div className="su-title">剧情存档</div>
          <div className="su-sub">{persona?.name ?? 'TA'} · {mine.length} 条剧情线</div>
        </div>
        <button type="button" className="su-textbtn" onClick={create}>
          新剧情
        </button>
      </div>

      <div className="su-body">
        {mine.length === 0 ? <div className="su-empty">还没有剧情线</div> : null}
        {mine.map((session) => (
          <div
            key={session.id}
            className="su-card"
            role="button"
            tabIndex={0}
            onClick={() => {
              selectSession(session.id)
              openChat(personaId, session.id)
            }}
            onKeyDown={(event) => {
              if (event.key === 'Enter') {
                selectSession(session.id)
                openChat(personaId, session.id)
              }
            }}
          >
            <div className="su-card-main">
              <div className="su-card-name">{session.title || '未命名剧情'}</div>
              <div className="su-card-meta">更新于 {formatDay(session.updatedAt)}</div>
            </div>
            <button
              type="button"
              className="su-iconbtn"
              aria-label="删除"
              onClick={(event) => {
                event.stopPropagation()
                if (window.confirm('删除这条剧情线？聊天记录会一起删除。')) {
                  void removeSession(session.id)
                  showToast('已删除')
                }
              }}
            >
              ⋯
            </button>
          </div>
        ))}
      </div>
    </div>
  )
}
