import { useState } from 'react'
import { Button } from '../../components/base/Button.js'
import { showToast } from '../../components/base/toastState.js'
import { createPersonaSession, selectSession } from '../../services/chat/store.js'
import { useMemoryStore } from '../../services/memory/store.js'
import { Sheet } from '../components/Sheet.js'
import { PRESETS, type PersonaPreset } from '../presets.js'
import { copyText, decodePersona, encodePersona } from '../share.js'
import { useCompanion } from '../store.js'

/** 广场：官方预设 + 分享码（未来换成联网角色市场） */
export const Plaza = () => {
  const personas = useMemoryStore((state) => state.personas)
  const createPersona = useMemoryStore((state) => state.createPersona)
  const openChat = useCompanion((state) => state.openChat)
  const [preview, setPreview] = useState<PersonaPreset | null>(null)
  const [shareOpen, setShareOpen] = useState(false)
  const [importOpen, setImportOpen] = useState(false)
  const [code, setCode] = useState('')
  const [myCode, setMyCode] = useState('')

  const startWith = (name: string, card: string, color?: string) => {
    const persona = createPersona({ name, personaCard: card, themeColor: color })
    const sessionId = createPersonaSession(persona.id, persona.name)
    selectSession(sessionId)
    setPreview(null)
    setImportOpen(false)
    openChat(persona.id, sessionId)
  }

  const importCode = () => {
    const shared = decodePersona(code)
    if (!shared) {
      showToast('分享码无效')
      return
    }
    setCode('')
    startWith(shared.name, shared.card, shared.color)
  }

  return (
    <div className="su-screen">
      <div className="su-scene" aria-hidden="true" />
      <div className="su-hero">
        <div>
          <div className="su-hero-title">广场</div>
          <div className="su-hero-sub">看看别人的 TA，或者把你的分享出去</div>
        </div>
      </div>

      <div className="su-body">
        <div className="su-banner">
          <div className="su-banner-title">联网广场正在建设</div>
          <div className="su-banner-text">
            之后这里会是一个角色市场：浏览、收藏、一键使用别人写好的角色，也能发布你自己的。
            现在先用官方预设和分享码。
          </div>
        </div>

        <div className="su-section-title">官方预设</div>
        <div className="su-grid">
          {PRESETS.map((preset) => (
            <button
              key={preset.id}
              type="button"
              className="su-preset"
              onClick={() => setPreview(preset)}
            >
              <span
                className="su-preset-avatar"
                style={{ backgroundColor: preset.color }}
              >
                {preset.name.slice(0, 1)}
              </span>
              <span className="su-preset-name">{preset.name}</span>
              <span className="su-preset-tag">{preset.tag}</span>
              <span className="su-preset-desc">{preset.tagline}</span>
            </button>
          ))}
        </div>

        <div className="su-section-title">分享与导入</div>
        <div className="su-rowline">
          <Button size="m" variant="outlined" onClick={() => setShareOpen(true)}>
            分享我的角色
          </Button>
          <Button size="m" variant="outlined" onClick={() => setImportOpen(true)}>
            导入分享码
          </Button>
        </div>
      </div>

      {preview ? (
        <Sheet open title={preview.name} onClose={() => setPreview(null)}>
          <div className="su-preview-head">
            <span className="su-avatar" style={{ backgroundColor: preview.color }}>
              {preview.name.slice(0, 1)}
            </span>
            <div className="su-header-main">
              <div className="su-title">{preview.name}</div>
              <div className="su-sub">{preview.tagline}</div>
            </div>
          </div>
          <div className="su-preview-card">{preview.card}</div>
          <div className="su-actions">
            <Button size="m" variant="outlined" onClick={() => setPreview(null)}>
              再看看
            </Button>
            <Button
              size="m"
              onClick={() => startWith(preview.name, preview.card, preview.color)}
            >
              使用这个角色
            </Button>
          </div>
        </Sheet>
      ) : null}

      <Sheet open={shareOpen} title="分享我的角色" onClose={() => setShareOpen(false)}>
        {personas.length === 0 ? (
          <div className="su-empty">还没有角色可以分享</div>
        ) : (
          personas.map((persona) => (
            <div key={persona.id} className="su-memo">
              <div className="su-memo-text">{persona.name}</div>
              <div className="su-memo-meta">
                <button
                  type="button"
                  className="su-link"
                  onClick={async () => {
                    const text = encodePersona(persona)
                    setMyCode(text)
                    const ok = await copyText(text)
                    showToast(ok ? '分享码已复制' : '复制失败，可以长按下面的文本手动复制')
                  }}
                >
                  复制分享码
                </button>
              </div>
            </div>
          ))
        )}
        {myCode ? <textarea className="su-textarea" readOnly value={myCode} /> : null}
      </Sheet>

      <Sheet open={importOpen} title="导入分享码" onClose={() => setImportOpen(false)}>
        <div className="su-note" style={{ marginTop: 0 }}>
          粘贴别人给你的 STA1 开头的分享码
        </div>
        <textarea
          className="su-textarea"
          value={code}
          placeholder="STA1...."
          onChange={(event) => setCode(event.target.value)}
        />
        <div className="su-actions">
          <Button size="m" variant="outlined" onClick={() => setImportOpen(false)}>
            取消
          </Button>
          <Button size="m" onClick={importCode}>
            导入并使用
          </Button>
        </div>
      </Sheet>
    </div>
  )
}
