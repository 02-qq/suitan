import { useState } from 'react'
import { Button } from '../../components/base/Button.js'
import { showToast } from '../../components/base/toastState.js'
import { useChatStore } from '../../services/chat/store.js'
import { useMemoryStore } from '../../services/memory/store.js'
import { useAccount } from '../account.js'
import { Sheet } from '../components/Sheet.js'
import { useCompanion } from '../store.js'

/** 登录框架：界面先搭好，服务未接入前只提供本地身份 */
const LoginSheet = ({ open, onClose }: { open: boolean; onClose: () => void }) => {
  const signInLocal = useAccount((state) => state.signInLocal)
  const [mode, setMode] = useState<'phone' | 'email'>('phone')
  const [name, setName] = useState('')

  return (
    <Sheet open={open} title="登录" onClose={onClose}>
      <div className="su-tabs">
        <button
          type="button"
          className={`su-tab${mode === 'phone' ? ' on' : ''}`}
          onClick={() => setMode('phone')}
        >
          手机号
        </button>
        <button
          type="button"
          className={`su-tab${mode === 'email' ? ' on' : ''}`}
          onClick={() => setMode('email')}
        >
          邮箱
        </button>
      </div>
      <input
        className="su-input"
        disabled
        placeholder={mode === 'phone' ? '手机号（尚未开放）' : '邮箱地址（尚未开放）'}
      />
      <input className="su-input" disabled style={{ marginTop: 8 }} placeholder="验证码（尚未开放）" />
      <div className="su-note">
        登录服务还没有接入。接入之后，这里会负责把角色、记忆和对话同步到云端；
        没有登录也不影响现在使用——所有数据都在本机。
      </div>
      <label className="su-label">先给本地身份起个名字</label>
      <input
        className="su-input"
        value={name}
        placeholder="例如：老周"
        onChange={(event) => setName(event.target.value)}
      />
      <div className="su-actions">
        <Button size="m" variant="outlined" onClick={onClose}>
          取消
        </Button>
        <Button
          size="m"
          onClick={() => {
            signInLocal(name)
            showToast('已创建本地身份')
            onClose()
          }}
        >
          以本地身份开始
        </Button>
      </div>
    </Sheet>
  )
}

/** 我的：身份、统计、设置入口 */
export const Mine = () => {
  const account = useAccount((state) => state.account)
  const signOut = useAccount((state) => state.signOut)
  const personas = useMemoryStore((state) => state.personas)
  const memories = useMemoryStore((state) => state.memories)
  const profile = useMemoryStore((state) => state.profile)
  const setProfile = useMemoryStore((state) => state.setProfile)
  const sessions = useChatStore((state) => state.sessions)
  const setSettings = useCompanion((state) => state.setSettings)
  const [loginOpen, setLoginOpen] = useState(false)

  const displayName = account?.name ?? profile.displayName ?? '我'

  return (
    <div className="su-screen">
      <div className="su-hero">
        <div>
          <div className="su-hero-title">我的</div>
          <div className="su-hero-sub">{account ? '本地身份' : '还没有登录'}</div>
        </div>
        <div className="su-avatar" style={{ backgroundColor: 'var(--su-accent, #c96f4a)' }}>
          {displayName.slice(0, 1)}
        </div>
      </div>

      <div className="su-body">
        <div className="su-card su-card-static">
          <div className="su-card-main">
            <div className="su-card-name">{displayName}</div>
            <div className="su-card-meta">
              {account ? '本地身份 · 数据只在这台手机' : '未登录 · 也可以正常使用'}
            </div>
          </div>
          {account ? (
            <button
              type="button"
              className="su-textbtn"
              onClick={() => {
                signOut()
                showToast('已退出本地身份')
              }}
            >
              退出
            </button>
          ) : (
            <button type="button" className="su-textbtn" onClick={() => setLoginOpen(true)}>
              登录
            </button>
          )}
        </div>

        <div className="su-stats">
          <div className="su-stat">
            <b>{personas.length}</b>
            <span>角色</span>
          </div>
          <div className="su-stat">
            <b>{sessions.length}</b>
            <span>对话</span>
          </div>
          <div className="su-stat">
            <b>{memories.length}</b>
            <span>记忆</span>
          </div>
        </div>

        <label className="su-label">TA 怎么称呼你</label>
        <input
          className="su-input"
          value={profile.displayName}
          placeholder="例如：老周"
          onChange={(event) => setProfile({ displayName: event.target.value })}
        />

        <div className="su-section-title">设置</div>
        <button type="button" className="su-menu-item" onClick={() => setSettings(true)}>
          API Key、模型与关于
        </button>

        <div className="su-note">
          内容由 AI 生成，仅供陪伴娱乐。聊天记录、记忆与 API Key 都只保存在这台手机上，不会上传到任何服务器。
        </div>
        <div className="su-note">
          基于开源项目 chat-demo 修改（MIT License，Copyright (c) 2026 DeepSeek）。
        </div>
      </div>

      <LoginSheet open={loginOpen} onClose={() => setLoginOpen(false)} />
    </div>
  )
}
