import { getVisibleMessages } from '../services/chat/branches.js'
import type { Message, Session } from '../services/chat/types.js'
import type { Persona } from '../services/memory/types.js'
import { saveFile, type SaveResult } from '../utils/download.js'

const pad = (value: number) => String(value).padStart(2, '0')

const stamp = (value: number) => {
  const date = new Date(value)
  return `${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(
    date.getMinutes()
  )}`
}

const fileNameStamp = () => {
  const date = new Date()
  return `${date.getFullYear()}${pad(date.getMonth() + 1)}${pad(date.getDate())}-${pad(
    date.getHours()
  )}${pad(date.getMinutes())}`
}

const textOf = (message: Message): string =>
  message.role === 'user'
    ? message.content
    : message.blocks.map((block) => (block.type === 'text' ? block.text : '')).join('')

/** 导出成回忆录纯文本：没有分隔线，每行一条对话 */
export const exportMemoir = async (
  persona: Persona,
  session: Session,
  userName: string
): Promise<SaveResult> => {
  const messages = getVisibleMessages(session).filter((message) => !message.excluded)
  const lines: string[] = []
  for (const message of messages) {
    const text = textOf(message)
      .split('\n')
      .filter((line) => !line.trim().startsWith('[['))
      .join('\n')
      .trim()
    if (!text) {
      continue
    }
    const who = message.role === 'user' ? userName : persona.name
    lines.push(`[${stamp(message.createdAt)}] ${who}：${text}`)
  }
  if (lines.length === 0) {
    return { native: false, ok: false }
  }
  const body = [`随谈 · 和${persona.name}的对话`, `对方：${userName}`, '', ...lines].join('\n')
  const name = `${persona.name}-回忆录-${fileNameStamp()}.txt`
  return saveFile(name, new Blob([`\uFEFF${body}`], { type: 'text/plain;charset=utf-8' }))
}
