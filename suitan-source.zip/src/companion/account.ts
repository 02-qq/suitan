import { create } from 'zustand'

/**
 * 账号框架（占位）：目前只有「本地身份」，没有服务器。
 * 以后接入登录时，把 signIn 换成真实请求、status 增加 'signed-in' 即可，
 * 其余界面按 account 渲染，不需要改。
 */
export type Account = {
  id: string
  name: string
  avatar?: string
  provider: 'local' | 'phone' | 'email'
}

const KEY = 'suitan:account'

const read = (): Account | null => {
  try {
    const raw = localStorage.getItem(KEY)
    if (!raw) {
      return null
    }
    const parsed = JSON.parse(raw) as Account
    if (!parsed || typeof parsed.id !== 'string' || typeof parsed.name !== 'string') {
      return null
    }
    return parsed
  } catch {
    return null
  }
}

const write = (account: Account | null) => {
  try {
    if (account) {
      localStorage.setItem(KEY, JSON.stringify(account))
    } else {
      localStorage.removeItem(KEY)
    }
  } catch {
    // 存储不可用时只在内存生效
  }
}

type AccountState = {
  account: Account | null
  signInLocal: (name: string) => void
  signOut: () => void
}

export const useAccount = create<AccountState>((set) => ({
  account: read(),
  signInLocal: (name) => {
    const account: Account = {
      id: `local-${Date.now()}`,
      name: name.trim() || '本地用户',
      provider: 'local',
    }
    write(account)
    set({ account })
  },
  signOut: () => {
    write(null)
    set({ account: null })
  },
}))
