import type { Persona } from '../services/memory/types.js'

/**
 * 角色分享码：STA1. + base64(JSON)。
 * 现在靠复制粘贴传递，未来广场联网后可以直接换成上传/下载同一个数据结构。
 */
export type SharedPersona = {
  name: string
  card: string
  color?: string
}

const PREFIX = 'STA1.'

export const encodePersona = (persona: Persona): string => {
  const payload: SharedPersona = {
    name: persona.name,
    card: persona.personaCard,
    color: persona.themeColor,
  }
  const bytes = new TextEncoder().encode(JSON.stringify(payload))
  let binary = ''
  for (const byte of bytes) {
    binary += String.fromCharCode(byte)
  }
  return `${PREFIX}${btoa(binary)}`
}

export const decodePersona = (code: string): SharedPersona | null => {
  const text = code.trim()
  if (!text.startsWith(PREFIX)) {
    return null
  }
  try {
    const binary = atob(text.slice(PREFIX.length))
    const bytes = Uint8Array.from(binary, (char) => char.charCodeAt(0))
    const parsed = JSON.parse(new TextDecoder().decode(bytes)) as SharedPersona
    if (typeof parsed.name !== 'string' || typeof parsed.card !== 'string') {
      return null
    }
    return parsed
  } catch {
    return null
  }
}

/** 复制到剪贴板：WebView 里 navigator.clipboard 可能不可用，退回输入框选中复制 */
export const copyText = async (text: string): Promise<boolean> => {
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(text)
      return true
    }
  } catch {
    // 继续尝试兜底方案
  }
  try {
    const area = document.createElement('textarea')
    area.value = text
    area.style.position = 'fixed'
    area.style.opacity = '0'
    document.body.appendChild(area)
    area.select()
    const ok = document.execCommand('copy')
    document.body.removeChild(area)
    return ok
  } catch {
    return false
  }
}
